HYPER WebIntoApp-ready HTML package.
Files: index.html, style.css, app.js
Note: Login, upload, likes/comments and video API require the Node.js backend (server.js) to be hosted separately and API in app.js configured to that backend URL.
