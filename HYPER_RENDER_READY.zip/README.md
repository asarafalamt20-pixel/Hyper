# HYPER — REAL FULL-STACK STARTER

This is a real backend-enabled HYPER project, not only a static Home screen.

## Included
- Real user registration/login with JWT
- SQLite database
- Real video upload (up to 1 GB in this starter)
- Video files served from the server
- Video player + view counter
- Likes
- Comments
- Search
- Categories
- Subscriptions API
- Profile/account UI
- Home, Shorts, Upload, Subscriptions, Library
- WebIntoApp-compatible frontend

## Run on a computer/server
1. Install Node.js 20+.
2. Open this folder in terminal.
3. Run `npm install`
4. Set a strong JWT_SECRET environment variable.
5. Run `npm start`
6. Open `http://YOUR-SERVER:3000`

## WebIntoApp
Do NOT upload this ZIP to the HTML Files field if you want the backend to run there.
First deploy this Node project to a server/hosting provider. Then put the deployed HTTPS URL into WebIntoApp's Online URL option.

## Important for production
This starter stores uploaded videos on the server disk. For a production app with many users/videos, replace local `/uploads` with object storage (S3/R2/Supabase Storage/Cloudinary) and use a managed database.

Never publish the default JWT_SECRET. Set your own secret before deployment.
